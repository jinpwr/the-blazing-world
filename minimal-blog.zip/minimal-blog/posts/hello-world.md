---
title: Setting up this log
date: 2026-08-18
summary: Why this blog has no build step, and how publishing actually works.
tags: meta, github-pages
---

This blog is four HTML files, three scripts, and a folder of Markdown. There is no
build step, no CI job, and nothing in `package.json` — because there is no
`package.json`.

## How publishing works

Writing happens at `/admin.html`. That page holds a GitHub token in your browser's
local storage and commits directly to this repository through the Contents API:

- the post becomes `posts/<slug>.md`
- pasted images become files under `images/YYYY-MM/`
- `posts/index.json` gets the new entry appended

GitHub Pages redeploys on the commit, usually within a minute.

## What you can take with you

Every entry exports as `.md` (the exact source, front matter included) or as `.pdf`
through a print stylesheet that strips the navigation. The whole archive exports at
once from the home page.

> The content is plain Markdown in a plain folder. If this site ever needs a real
> static site generator, the `posts/` directory moves across untouched.
